"""Small JSON macro store in the app's private data directory."""
import json
from pathlib import Path
from kivy.app import App

class MacroStore:
    def __init__(self):
        self.path = Path(App.get_running_app().user_data_dir) / "macros.json"

    def _read(self):
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def save(self, name, steps):
        data = self._read()
        data[name] = steps
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def all(self):
        return self._read()
