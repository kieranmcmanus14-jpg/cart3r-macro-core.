"""Macro data model and safe preview runner.

Actual taps/swipes across other Android apps are intentionally delegated to a
native, user-consented AccessibilityService in a production Android build.
"""
from dataclasses import dataclass, asdict
import time

@dataclass
class MacroStep:
    kind: str
    args: dict

    def to_dict(self):
        return asdict(self)

class MacroEngine:
    ALLOWED = {"wait", "tap", "swipe", "note"}

    def validate(self, steps):
        for index, step in enumerate(steps):
            if step.get("kind") not in self.ALLOWED:
                raise ValueError(f"Unsupported step at position {index + 1}")
            args = step.get("args", {})
            if step["kind"] == "wait":
                seconds = float(args.get("seconds", 0))
                if not 0 <= seconds <= 300:
                    raise ValueError("wait must be between 0 and 300 seconds")
            if step["kind"] == "tap":
                for key in ("x", "y"):
                    value = float(args[key])
                    if not 0 <= value <= 1:
                        raise ValueError("tap coordinates must be normalized 0..1")
            if step["kind"] == "swipe":
                for key in ("x1", "y1", "x2", "y2"):
                    value = float(args[key])
                    if not 0 <= value <= 1:
                        raise ValueError("swipe coordinates must be normalized 0..1")
                duration = float(args.get("duration", .3))
                if not .05 <= duration <= 10:
                    raise ValueError("swipe duration must be 0.05..10 seconds")
        return True

    def preview(self, steps):
        self.validate(steps)
        if not steps:
            return "This macro has no steps."
        lines = ["SAFE PREVIEW — no touches will be sent.\n"]
        for i, step in enumerate(steps, 1):
            lines.append(f"{i}. {step['kind'].upper()}: {step.get('args', {})}")
        lines.append("\nTo execute across other apps, connect a native Android "
                     "AccessibilityService and obtain explicit user consent.")
        return "\n".join(lines)
