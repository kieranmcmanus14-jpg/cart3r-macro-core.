from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.properties import StringProperty, ListProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.camera import Camera
from kivy.utils import platform

from color_detector import ColorDetector
from macro_engine import MacroEngine, MacroStep
from storage import MacroStore

KV = r"""
<RootUI>:
    orientation: "vertical"
    padding: "12dp"
    spacing: "9dp"
    canvas.before:
        Color:
            rgba: 0.025, 0.025, 0.035, 1
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        size_hint_y: None
        height: "52dp"
        Label:
            text: "[b]CART3R // MACRO CORE[/b]"
            markup: True
            color: 1, 0.18, 0.28, 1
            font_size: "19sp"
            halign: "left"
        Label:
            text: "ANDROID BUILD 0.1"
            color: .65, .65, .7, 1
            font_size: "10sp"
            size_hint_x: .45
    Label:
        text: root.status
        size_hint_y: None
        height: "30dp"
        color: .9, .75, .78, 1
        text_size: self.width, None
    TabbedPanel:
        do_default_tab: False
        background_color: .07, .07, .09, 1
        TabbedPanelItem:
            text: "COLOR"
            BoxLayout:
                orientation: "vertical"
                padding: "8dp"
                spacing: "8dp"
                Label:
                    text: "Color detection source"
                    size_hint_y: None
                    height: "28dp"
                    color: 1, 1, 1, 1
                Spinner:
                    id: source
                    text: "Camera preview"
                    values: ["Camera preview", "Test image"]
                    size_hint_y: None
                    height: "44dp"
                Camera:
                    id: camera
                    resolution: (640, 480)
                    play: True if source.text == "Camera preview" else False
                BoxLayout:
                    size_hint_y: None
                    height: "42dp"
                    spacing: "6dp"
                    Button:
                        text: "Start color scan"
                        on_release: root.start_scan()
                    Button:
                        text: "Stop scan"
                        on_release: root.stop_scan()
                Label:
                    id: color_result
                    text: "No color scan running"
                    color: 1, 1, 1, 1
                    size_hint_y: None
                    height: "42dp"
                Label:
                    text: "HSV target range: adjustable in settings / color_detector.py"
                    color: .65, .65, .7, 1
                    font_size: "11sp"
                    size_hint_y: None
                    height: "30dp"
        TabbedPanelItem:
            text: "MACROS"
            BoxLayout:
                orientation: "vertical"
                padding: "8dp"
                spacing: "8dp"
                TextInput:
                    id: macro_name
                    hint_text: "Macro name"
                    multiline: False
                    size_hint_y: None
                    height: "44dp"
                Spinner:
                    id: action_type
                    text: "wait"
                    values: ["wait", "tap", "swipe", "note"]
                    size_hint_y: None
                    height: "44dp"
                TextInput:
                    id: action_args
                    hint_text: "Arguments (e.g. 1.0 for wait; x,y for tap)"
                    multiline: False
                    size_hint_y: None
                    height: "44dp"
                BoxLayout:
                    size_hint_y: None
                    height: "44dp"
                    spacing: "6dp"
                    Button:
                        text: "Add step"
                        on_release: root.add_step()
                    Button:
                        text: "Save macro"
                        on_release: root.save_macro()
                Label:
                    id: step_list
                    text: "No steps yet"
                    color: 1, 1, 1, 1
                    text_size: self.width, None
                    valign: "top"
                Button:
                    text: "Run macro (safe preview)"
                    size_hint_y: None
                    height: "48dp"
                    on_release: root.run_preview()
        TabbedPanelItem:
            text: "SETTINGS"
            BoxLayout:
                orientation: "vertical"
                padding: "10dp"
                spacing: "10dp"
                Label:
                    text: "Permissions and platform integration"
                    color: 1, .3, .38, 1
                    size_hint_y: None
                    height: "35dp"
                Label:
                    text: "Camera permission enables camera-based color detection. Full phone-screen capture requires Android MediaProjection consent. Cross-app taps/swipes require an AccessibilityService that is not included in this Python-only MVP."
                    color: .85, .85, .88, 1
                    text_size: self.width, None
                    halign: "left"
                    valign: "top"
                Button:
                    text: "Show integration status"
                    size_hint_y: None
                    height: "46dp"
                    on_release: root.show_integration_status()
"""

class RootUI(BoxLayout):
    status = StringProperty("READY // Camera-based color scan and macro editor")
    steps_text = StringProperty("")
    steps = ListProperty([])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.detector = ColorDetector()
        self.engine = MacroEngine()
        self.store = MacroStore()
        self.scan_event = None
        self.current_macro_name = "Untitled Macro"

    def start_scan(self):
        if self.ids.source.text != "Camera preview":
            self.status = "Select camera preview, or add image-file input in a later build."
            return
        self.ids.camera.play = True
        self.scan_event = Clock.schedule_interval(self._scan_camera, 0.5)
        self.status = "COLOR SCAN ACTIVE // camera frames"

    def stop_scan(self):
        if self.scan_event:
            self.scan_event.cancel()
            self.scan_event = None
        self.status = "COLOR SCAN STOPPED"

    def _scan_camera(self, _dt):
        cam = self.ids.camera
        texture = cam.texture
        if not texture:
            return
        try:
            # Kivy texture pixels are RGBA; OpenCV detector accepts RGB/RGBA arrays.
            import numpy as np
            frame = np.frombuffer(texture.pixels, dtype=np.uint8)
            frame = frame.reshape(texture.height, texture.width, 4)
            result = self.detector.detect(frame)
            self.ids.color_result.text = (
                f"Target pixels: {result['count']} | "
                f"Coverage: {result['coverage']:.1f}% | "
                f"Center: {result['center']}"
            )
        except Exception as exc:
            self.ids.color_result.text = f"Frame error: {exc}"

    def add_step(self):
        kind = self.ids.action_type.text
        raw = self.ids.action_args.text.strip()
        try:
            if kind == "wait":
                args = {"seconds": float(raw or "1")}
            elif kind == "tap":
                parts = [float(v.strip()) for v in raw.split(",")]
                if len(parts) != 2:
                    raise ValueError("tap requires x,y")
                args = {"x": parts[0], "y": parts[1]}
            elif kind == "swipe":
                parts = [float(v.strip()) for v in raw.split(",")]
                if len(parts) != 5:
                    raise ValueError("swipe requires x1,y1,x2,y2,duration")
                args = {"x1": parts[0], "y1": parts[1], "x2": parts[2],
                        "y2": parts[3], "duration": parts[4]}
            else:
                args = {"text": raw}
            step = MacroStep(kind=kind, args=args)
            self.steps.append(step.to_dict())
            self._refresh_steps()
            self.status = f"STEP ADDED // {kind}"
        except Exception as exc:
            self.status = f"INVALID STEP // {exc}"

    def _refresh_steps(self):
        if not self.steps:
            self.ids.step_list.text = "No steps yet"
        else:
            self.ids.step_list.text = "\n".join(
                f"{i+1}. {s['kind']}  {s['args']}" for i, s in enumerate(self.steps)
            )

    def save_macro(self):
        name = self.ids.macro_name.text.strip() or "Untitled Macro"
        self.store.save(name, self.steps)
        self.status = f"SAVED // {name}"

    def run_preview(self):
        # Deliberately preview-only: no cross-app touch injection is performed.
        summary = self.engine.preview(self.steps)
        Popup(title="Macro preview", content=Label(text=summary),
              size_hint=(.9, .7)).open()
        self.status = "PREVIEW COMPLETE // no device actions executed"

    def show_integration_status(self):
        msg = (
            "Python/Kivy UI: available\n"
            "Camera color detection: available\n"
            "Macro editing and local JSON storage: available\n"
            "Full-screen capture: requires native MediaProjection bridge\n"
            "Cross-app touch automation: requires user-enabled AccessibilityService\n"
            "Those native Android services are not included in this MVP."
        )
        Popup(title="Integration status", content=Label(text=msg),
              size_hint=(.92, .65)).open()


class MacroCoreApp(App):
    def build(self):
        Builder.load_string(KV)
        return RootUI()

    def on_stop(self):
        if self.root:
            self.root.stop_scan()


if __name__ == "__main__":
    MacroCoreApp().run()
