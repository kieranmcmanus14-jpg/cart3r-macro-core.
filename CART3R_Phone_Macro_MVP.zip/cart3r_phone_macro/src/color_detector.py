"""HSV-based color detection for camera frames or supplied screenshots."""
import cv2
import numpy as np

class ColorDetector:
    def __init__(self, lower_hsv=(0, 120, 80), upper_hsv=(10, 255, 255),
                 min_area=12):
        self.lower = np.array(lower_hsv, dtype=np.uint8)
        self.upper = np.array(upper_hsv, dtype=np.uint8)
        self.min_area = min_area

    def set_hsv_range(self, lower, upper):
        self.lower = np.array(lower, dtype=np.uint8)
        self.upper = np.array(upper, dtype=np.uint8)

    def detect(self, frame):
        if frame is None or frame.size == 0:
            raise ValueError("empty frame")
        if frame.shape[-1] == 4:
            rgb = cv2.cvtColor(frame, cv2.COLOR_RGBA2RGB)
        else:
            rgb = frame
        hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)

        # Red wraps around the HSV hue boundary, so combine two masks.
        if int(self.lower[0]) <= 10 and int(self.upper[0]) >= 170:
            mask_a = cv2.inRange(hsv, self.lower, self.upper)
            low_red = np.array([170, int(self.lower[1]), int(self.lower[2])], np.uint8)
            high_red = np.array([180, int(self.upper[1]), int(self.upper[2])], np.uint8)
            mask_b = cv2.inRange(hsv, low_red, high_red)
            mask = cv2.bitwise_or(mask_a, mask_b)
        else:
            mask = cv2.inRange(hsv, self.lower, self.upper)

        mask = cv2.medianBlur(mask, 5)
        count = int(cv2.countNonZero(mask))
        coverage = 100.0 * count / mask.size
        moments = cv2.moments(mask)
        if moments["m00"]:
            center = (int(moments["m10"] / moments["m00"]),
                      int(moments["m01"] / moments["m00"]))
        else:
            center = None
        return {"mask": mask, "count": count, "coverage": coverage,
                "center": center}
