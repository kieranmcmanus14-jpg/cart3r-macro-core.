# CART3R Macro Core — Android Python MVP

A Kivy Android app foundation with:
- Camera-frame HSV color detection.
- Pixel-count, coverage percentage, and detected-region centroid.
- Macro step editor (`wait`, `tap`, `swipe`, `note`).
- Local JSON macro storage.
- Safe macro preview (does not inject touches into other apps).

## Important platform boundary

This MVP does **not** capture the phone's entire screen or perform taps/swipes
inside other apps. Android requires native, user-consented integrations:

1. **Screen capture:** Android `MediaProjection` service and its runtime consent
   dialog. Feed captured frames into `ColorDetector.detect(frame)`.
2. **Cross-app gestures:** a native Android `AccessibilityService`, explicitly
   enabled by the device owner. Implement tap/swipe dispatch there and expose a
   narrow bridge to Python. Do not try to bypass Android permission prompts.
3. Keep a visible stop control, action limits, and clear indicators whenever
   automation is active.

## Build

Buildozer is best run on Linux (or WSL2 with a supported Linux environment).
Install Java, build tools, and Buildozer, then from this project directory:

```bash
python -m pip install --upgrade buildozer Cython
buildozer android debug
```

The APK is normally written under `bin/`. Install it on your own Android device
using Android's normal installation flow. Camera permission will be requested
when the camera feature is used.

## Run on desktop for development

```bash
python -m pip install kivy numpy opencv-python
cd src
python main.py
```

## Color detection

The default detector is configured for red in HSV. Edit the constructor values
in `main.py` or call `ColorDetector.set_hsv_range(lower, upper)`.

OpenCV hue is 0–180; saturation and value are 0–255. A selected-pixel picker
can be implemented by sampling `hsv[y, x]` from a frame and creating a
tolerance range around that HSV value. The detector already accepts any frame,
so the same method works with camera frames, imported images, or frames
provided by a future MediaProjection bridge.

## Macro coordinate format

Tap and swipe coordinates are normalized from 0.0 to 1.0, relative to screen
width and height. This makes saved macros less dependent on device resolution.
The current editor accepts raw values and validates them before preview.

## Project structure

```text
cart3r_phone_macro/
├── buildozer.spec
├── README.md
└── src/
    ├── main.py
    ├── color_detector.py
    ├── macro_engine.py
    └── storage.py
```
