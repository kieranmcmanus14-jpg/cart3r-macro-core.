[app]
title = CART3R Macro Core
package.name = cart3rmacro
package.domain = org.cart3r
source.dir = src
source.include_exts = py,kv,png,jpg,json
version = 0.1.0
requirements = python3,kivy,numpy,opencv
orientation = portrait
fullscreen = 0

# Camera access is only for camera-based color detection in this MVP.
android.permissions = CAMERA
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
p4a.branch = develop

[buildozer]
log_level = 2
warn_on_root = 1
