# CART3R Macro Core 0.2 — Android cloud-build project

This revision removes the OpenCV/NumPy requirement and uses a small pure-Python
HSV detector so the initial Android build has fewer native dependencies.

## What works in this MVP
- Kivy Android interface
- Camera-frame color detection (sampled pixels)
- Red target by default; detector supports orange, yellow, green, cyan, blue,
  and purple through `ColorDetector.set_target(...)`
- Macro editor and local JSON storage
- Safe macro preview only

## Not included yet
- Full-screen capture. This needs Android MediaProjection and its consent UI.
- Cross-app taps/swipes. This needs a native Android AccessibilityService that
  the device owner explicitly enables.
- Actual macro playback. The current macro engine validates and previews steps.

## Build without a computer (cloud build from your phone)
1. Create a GitHub repository using your phone browser.
2. Upload the contents of this project to the repository, preserving the
   `.github/workflows/android.yml` path.
3. In the repository, open Actions and run "Build CART3R Android APK".
4. When the workflow finishes, open its run page and download the
   `cart3r-macro-core-debug-apk` artifact.
5. Extract the artifact ZIP on the phone, tap the APK, and follow Android's
   installation prompts.

The workflow builds on GitHub-hosted Ubuntu, not on the phone. No GitHub
password or access token is needed in the workflow file. Keep the repository
private if you do not want the source public.

## Local development
Buildozer's documented Android build host is Linux or macOS (Windows can use
WSL). This is why this project includes a cloud workflow for a phone-only setup.
