"""Dependency-free HSV color detection for RGBA camera frames."""
import colorsys

class ColorDetector:
    def __init__(self, target="red", hue_tolerance=0.045,
                 min_saturation=0.42, min_value=0.28, sample_step=4):
        self.target = target
        self.hue_tolerance = hue_tolerance
        self.min_saturation = min_saturation
        self.min_value = min_value
        self.sample_step = max(1, int(sample_step))

    def set_target(self, target):
        if target not in {"red", "orange", "yellow", "green", "cyan", "blue", "purple"}:
            raise ValueError("Unsupported target color")
        self.target = target

    def _hue(self):
        return {
            "red": 0.0, "orange": 0.083, "yellow": 0.167,
            "green": 0.333, "cyan": 0.5, "blue": 0.667,
            "purple": 0.80
        }[self.target]

    def detect_rgba(self, pixels, width, height):
        data = memoryview(pixels)
        expected = width * height * 4
        if len(data) < expected:
            raise ValueError("Camera frame buffer is incomplete")

        hits = 0
        total = 0
        sum_x = 0
        sum_y = 0
        target_hue = self._hue()
        step = self.sample_step

        for y in range(0, height, step):
            row = y * width * 4
            for x in range(0, width, step):
                i = row + x * 4
                r, g, b = data[i] / 255, data[i+1] / 255, data[i+2] / 255
                h, s, v = colorsys.rgb_to_hsv(r, g, b)
                hue_distance = abs(h - target_hue)
                hue_distance = min(hue_distance, 1.0 - hue_distance)
                total += 1
                if (hue_distance <= self.hue_tolerance and
                    s >= self.min_saturation and v >= self.min_value):
                    hits += 1
                    sum_x += x
                    sum_y += y

        center = (round(sum_x / hits), round(sum_y / hits)) if hits else None
        return {
            "count": hits,
            "coverage": (100.0 * hits / total) if total else 0.0,
            "center": center
        }
