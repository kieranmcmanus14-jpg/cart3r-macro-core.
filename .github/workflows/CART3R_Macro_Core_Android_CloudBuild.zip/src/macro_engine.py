"""Macro model and safe preview. No touch injection is performed."""
from dataclasses import dataclass, asdict

@dataclass
class MacroStep:
    kind: str
    args: dict

    def to_dict(self):
        return asdict(self)

class MacroEngine:
    ALLOWED = {"wait", "tap", "swipe", "note"}

    def validate(self, steps):
        for index, step in enumerate(steps):
            kind = step.get("kind")
            args = step.get("args", {})
            if kind not in self.ALLOWED:
                raise ValueError(f"Unsupported step at position {index + 1}")
            if kind == "wait":
                if not 0 <= float(args.get("seconds", 0)) <= 300:
                    raise ValueError("wait must be between 0 and 300 seconds")
            if kind == "tap":
                for key in ("x", "y"):
                    if not 0 <= float(args[key]) <= 1:
                        raise ValueError("tap coordinates must be 0..1")
            if kind == "swipe":
                for key in ("x1", "y1", "x2", "y2"):
                    if not 0 <= float(args[key]) <= 1:
                        raise ValueError("swipe coordinates must be 0..1")
                if not .05 <= float(args.get("duration", .3)) <= 10:
                    raise ValueError("swipe duration must be 0.05..10 seconds")
        return True

    def preview(self, steps):
        self.validate(steps)
        if not steps:
            return "This macro has no steps."
        lines = ["SAFE PREVIEW — no touches will be sent.\n"]
        for i, step in enumerate(steps, 1):
            lines.append(f"{i}. {step['kind'].upper()}: {step.get('args', {})}")
        lines.append("\nCross-app automation is not enabled in this build.")
        return "\n".join(lines)
